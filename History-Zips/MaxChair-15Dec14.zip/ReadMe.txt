Product: Max Chair, December 2014

Designer: Max Kokinakes

Support:  http://forums.obrary.com/category/designs/max-chair

Distributed by:  Obrary, Inc.  http://obrary.com.  Obrary - democratized product design